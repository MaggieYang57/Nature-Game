
public class VeinVisitor extends AllFalseEntityVisitor{

	public Boolean visit(Vein vein)
	{
		return true; 
	}
}
