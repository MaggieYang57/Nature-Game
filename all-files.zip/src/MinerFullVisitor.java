
public class MinerFullVisitor extends AllFalseEntityVisitor{

	public Boolean visit(MinerFull minerfull)
	{
		return true; 
	}
}
