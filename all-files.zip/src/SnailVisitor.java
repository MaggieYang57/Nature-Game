
public class SnailVisitor extends AllFalseEntityVisitor{

	public Boolean visit(Snail snail)
	{
		return true; 
	}
}
