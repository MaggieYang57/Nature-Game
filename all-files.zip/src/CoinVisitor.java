
public class CoinVisitor extends AllFalseEntityVisitor{

	public Boolean visit(Coin c)
	{
		return true; 
	}
}
