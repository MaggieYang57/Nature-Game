
public class SmithVisitor extends AllFalseEntityVisitor{

	public Boolean visit(Smith smith)
	{
		return true; 
	}
}
