
public class RaccoonVisitor extends AllFalseEntityVisitor{

	public Boolean visit(Raccoon r)
	{
		return true; 
	}
}
