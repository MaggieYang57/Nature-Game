public class BlobEntityVisitor extends AllFalseEntityVisitor{
  
	public Boolean visit(Blob blob)
	{
		return true; 
	}
}
