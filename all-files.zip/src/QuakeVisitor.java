
public class QuakeVisitor extends AllFalseEntityVisitor{

	public Boolean visit(Quake quake)
	{
		return true; 
	}
}
