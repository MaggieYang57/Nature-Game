
public class ObstacleVisitor extends AllFalseEntityVisitor{

	public Boolean visit(Obstacle ob)
	{
		return true; 
	}
}
