
public class MinerNotFullVisitor extends AllFalseEntityVisitor{

	public Boolean visit(MinerNotFull notfull)
	{
		return true; 
	}
}
