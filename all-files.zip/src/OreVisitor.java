
public class OreVisitor extends AllFalseEntityVisitor{

	public Boolean visit(Ore ore)
	{
		return true; 
	}
}
